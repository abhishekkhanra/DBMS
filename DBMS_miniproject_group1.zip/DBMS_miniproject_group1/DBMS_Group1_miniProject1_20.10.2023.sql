-- 1.	Show the percentage of wins of each bidder in the order of highest to lowest percentage. 
use ipl;
#tables used:
select * from ipl_bidder_points;
select * from ipl_bidding_details;
-- final answer
select bidder_id,dense_rank()over(order by win_pct desc) as drnk,win_pct from
(select t.bidder_id,t.no_of_bids,((cbs/no_of_bids)*100) as win_pct from
(select ibd.bidder_id,ibp.no_of_bids, count(bid_status) as cbs from ipl_bidder_points as ibp join ipl_bidding_details as ibd on 
ibd.bidder_id=ibp.bidder_id where bid_status="Won" group by ibd.bidder_id,ibp.no_of_bids) as t) as n;

-- 2.	Display the number of matches conducted at each stadium with the stadium name and city.
# Tables used:
select * from ipl_match_schedule;
select * from ipl_stadium;

select distinct count(match_id)over(partition by ims.stadium_id)as count_matches_stadium, stadium_name,city 
from ipl_match_schedule as ims
join ipl_stadium as ips 
on ims.stadium_id=ips.stadium_id where Status="Completed";


-- 3.	In a given stadium, what is the percentage of wins by a team which has won the toss?
# Tables used:
select * from ipl_match;
select * from ipl_stadium;
select * from ipl_match_schedule;

select stad.stadium_id,stad.stadium_name,
(select count(*) from ipl_match mat inner join ipl_match_schedule schd
on mat.match_id=schd.match_id
where schd.stadium_id=stad.stadium_id and (toss_winner = match_winner))/
(select count(*) from ipl_match_schedule schd where schd.stadium_id = stad.stadium_id) * 100
as 'toss and match wins % ' 
from ipl_stadium stad;

 
 -- 4.	Show the total bids along with the bid team and team name.
  -- including cancelled bids
  # Tables used:
  select * from ipl_team;
  select * from ipl_bidding_details;
  
select distinct count(bidder_id) over(partition by bid_team,team_name) as total_bid, bid_team,team_name 
from ipl_bidding_details as ibd
join ipl_team as it on ibd.bid_team=it.team_id;
  
  -- 5.	Show the team id who won the match as per the win details.
  
-- final answer since we have to use win details column
#Tables used:
select * from ipl_match;
select * from ipl_team;


select im.match_id,it.team_id,im.win_details from ipl_team as it join ipl_match as im
on im.win_details like concat("%",it.remarks,"%");

    -- 6.	Display total matches played, total matches won and total matches lost by the team along with its team name.
    
    select * from ipl_team_standings;
    -- final answer - left join
    
    select it.team_id, it.team_name, count(*) as total,
    sum(case when im.win_details like concat("%",it.remarks,"%") then 1 else 0 end) as total_win,
    sum(case when im.win_details not like concat("%",it.remarks,"%") then 1 else 0 end) as total_loss
    from ipl_team it left join ipl_match im
    on it.team_id = im.team_id1 or it.team_id = im.team_id2
    group by it.team_id, it.team_name;

    
    -- 7.	Display the bowlers for the Mumbai Indians team.
    #Tables used:
    select * from ipl_team;
    select * from ipl_team_players;
    select * from ipl_player;
    -- final answer
    
    select distinct itp.team_id,it.team_name,ip.player_id,ip.player_name,itp.player_role 
    from ipl_team_players as itp join ipl_team as it
    on itp.team_id=it.team_id
    join ipl_player as ip on itp.player_id=ip.player_id where itp.player_role="Bowler" and it.team_name="Mumbai Indians";
    
    -- 8.	How many all-rounders are there in each team, Display the teams with more than 4 all-rounders in descending order.
    #Tables used:
	select * from ipl_team;
    select * from ipl_team_players;
    select * from ipl_player;
   -- final answer - assumption only for player playing for his current team
   
select t.team_id, it.team_name, allrounder_count,dense_rank()over(order by allrounder_count desc) from
(select distinct team_id,count(player_role) over(partition by team_id) as allrounder_count from ipl_team_players where 
player_role="All-Rounder")as t 
join ipl_team as it on t.team_id=it.team_id where allrounder_count>4;
    
    
/* 9. Write a query to get the total bidders points for each bidding status of those bidders who bid on CSK when it won the match in
 M. Chinnaswamy Stadium bidding year-wise.Note the total bidders’ points in descending order and the year is bidding year.
Display columns: bidding status, bid date as year, total bidder’s points*/
select * from ipl_bidder_details;
select * from ipl_bidder_points;
select * from ipl_bidding_details;
-- final final answer

select * from ipl_match;
select distinct ibp.bidder_id,total_points,ibd.bid_Status,year(bid_date),stadium_name 
from ipl_bidder_points as ibp 
join ipl_bidding_details as ibd on ibp.bidder_id=ibd.bidder_id 
join ipl_match_schedule as ims on ibd.schedule_id =ims.schedule_id
join ipl_match as im on ims.match_id=im.match_id
join ipl_stadium as ips on ims.stadium_id=ips.stadium_id 
where win_details like "%CSK%Won%" and stadium_name like"%Chin%"
order by total_points desc;

/*10.	Extract the Bowlers and All Rounders those are in the 5 highest number of wickets.
Note 
1. use the performance_dtls column from ipl_player to get the total number of wickets
2. Do not use the limit method because it might not give appropriate results when players have the same number of wickets
3.	Do not use joins in any cases.
4.	Display the following columns teamn_name, player_name, and player_role.*/
#Tables used:
select * from ipl_players;
select *from ipl_team_players;
select * from ipl_team;

-- wickets
select substr(substr(performance_dtls,instr(performance_dtls,"w"),6),5) as wickets from ipl_player;
-- bowler,allrounder
select player_id from ipl_team_players where player_role in ("Bowler","All-Rounder");
-- final answer without joins ( as mentioned in Q)
select wickets, player_id,player_name,
(select player_role from ipl_team_players itp where itp.player_id = g.player_id and player_role in ("Bowler","All-Rounder"))player_role,
(select team_name from ipl_team  where team_id in(select team_id from ipl_team_players ab where ab.player_id = g.player_id)) 
as team_name from (
select wickets, player_id,player_name, drnk from(
select wickets,player_id,player_name, dense_rank()over(order by wickets desc) as drnk from
(select sum(substr(substr(performance_dtls,instr(performance_dtls,"w"),6),5)) as wickets,player_id,player_name
from ipl_player as ip
group by player_id )as t)as p
where drnk<6  AND (
        SELECT player_role
        FROM ipl_team_players itp
        WHERE itp.player_id = p.player_id
        AND player_role IN ('Bowler', 'All-Rounder')
    ) IS NOT NULL
) as g;

/* 11.	show the percentage of toss wins of each bidder and display the results in descending order based on the percentage */
#Tables used:
select * from ipl_bidding_details;
select * from ipl_match;
select * from ipl_match_schedule;

-- counting bids where bidteam won the toss
With total_Counts_table as 
(select ibd.bidder_id, count(ibd.bidder_id) as total_count from ipl_bidding_details as ibd 
join ipl_match_schedule as ims on ibd.schedule_id=ims.schedule_id join ipl_match as im on ims.match_id=im.match_id
 group by ibd.bidder_id), toss_win_count_table as
(select distinct ibd.bidder_id,count(ibd.bidder_id) as tosswincount from  ipl_bidding_details as  ibd 
join ipl_match_schedule as ims on ibd.schedule_id=ims.schedule_id join ipl_match as im on ims.match_id=im.match_id where ibd.bid_team
=case when toss_winner=1 then team_id1 when toss_winner=2 then team_id2 end group by bidder_id)
select tct.bidder_id,tct.total_count,twct.tosswincount, (twct.tosswincount/tct.total_count)*100 as bidteam_tosswin_pct
 from total_counts_table as tct join toss_win_count_table as twct
on tct.bidder_id=twct.bidder_id order by bidteam_tosswin_pct desc;

/* 12.	find the IPL season which has min duration and max duration.
Output columns should be like the below:
 Tournment_ID, Tourment_name, Duration column, Duration */
#Tables used:
select * from ipl_tournament;

with ipl as(select Tournmt_ID,Tournmt_NAME,
DATEDIFF(TO_DATE,FROM_DATE) as Duration,
CASE
when DATEDIFF(TO_DATE, FROM_DATE) = ( select MAX(DATEDIFF(TO_DATE, FROM_DATE)) from ipl_tournament) then 'Max_duration'
when DATEDIFF(TO_DATE, FROM_DATE) = ( select MIN(DATEDIFF(TO_DATE, FROM_DATE)) from ipl_tournament) then 'MIN_duration'
end as duration_column
from ipl_tournament)
select * from ipl where duration_column is not null;


/* 13.	Write a query to display to calculate the total points month-wise for the 2017 bid year. sort the results based on total points in descending order and month-wise in ascending order.
Note: Display the following columns:
1.	Bidder ID, 2. Bidder Name, 3. bid date as Year, 4. bid date as Month, 5. Total points
Only use joins for the above query queries. */


-- Answer . Joined for Bid Year 2018 since points table not available for Bid Year 2017
#Tables used:
select * from ipl_bidder_points;
select * from ipl_bidding_details;
select * from ipl_bidder_details;
SELECT ibp.Bidder_Id,ipbd.bidder_name AS Bidder_Name,YEAR(ibd.Bid_Date) AS Year, MONTH(ibd.Bid_Date) AS Month, ibp.Total_Points
FROM IPL_Bidder_Points ibp
JOIN IPL_Bidding_Details ibd ON ibp.Bidder_Id = ibd.Bidder_Id
JOIN IPL_bidder_details as ipbd ON ibp.Bidder_Id = ipbd.Bidder_Id
WHERE YEAR(ibd.Bid_Date) = '2018'
GROUP BY ibp.Bidder_Id,Bidder_Name,Year,Month,ibp.Total_Points
ORDER BY ibp.Total_Points DESC,Month ASC;

/*14.	Write a query for the above question using sub queries by having the same constraints as the above question. */

-- Joined for Bid Year 2018 since points table not available for Bid Year 2017
SELECT ibd.Bidder_Id,(select ipbd.bidder_name FROM ipl_bidder_details AS ipbd WHERE ipbd.bidder_id = ibd.bidder_id) AS Bidder_Name,
year(bid_date) as Year,month(bid_date) as Month, (select total_points from ipl_bidder_points as ibp where ibp.bidder_id=ibd.bidder_id) 
as Total_Points from ipl_bidding_details as ibd where year(bid_date)="2018"
GROUP BY ibd.Bidder_Id,Bidder_Name,Year,Month,Total_Points
ORDER BY Total_Points DESC,Month ASC;


/*15.	Write a query to get the top 3 and bottom 3 bidders based on the total bidding points for the 2018 bidding year.
Output columns should be: like:Bidder Id, Ranks (optional), Total points, Highest_3_Bidders --> columns contains name of bidder,
 Lowest_3_Bidders  --> columns contains name of bidder */
 

select * from ipl_bidder_points;

select bidder_id,min_rank,max_rank, total_points,bidder_name,
case when max_rank<4 then bidder_name end as Highest_3_Bidders,
case when min_rank<4 then bidder_name end as Lowest_3_Bidders from (
select distinct ibd.bidder_id, ibp.total_points,dense_rank() over(order by ibp.total_points asc) as min_rank,
dense_rank() over(order by ibp.total_points desc) as max_rank,ibd.bidder_name from ipl_bidder_details as ibd 
join ipl_bidder_points as ibp on ibd.bidder_id=ibp.bidder_id join ipl_bidding_details as ipbd
on ibd.bidder_id=ipbd.bidder_id where year(bid_date)="2018") as t where min_rank<=1 or max_rank<4;




/* 16.	Create two tables called Student_details and Student_details_backup.

Table 1: Attributes 		Table 2: Attributes
Student id, Student name, mail id, mobile no.	Student id, student name, mail id, mobile no.

Feel free to add more columns the above one is just an example schema.
Assume you are working in an Ed-tech company namely Great Learning where you will be inserting and modifying the details
 of the students in the Student details table. Every time the students changed their details like mobile number, You need to 
 update their details in the student details table.  Here is one thing you should ensure whenever the new students' details come ,
 you should also store them in the Student backup table so that if you modify the details in the student details table, you will be 
 having the old details safely. You need not insert the records separately into both tables rather Create a trigger in such a way that
 It should insert the details into the Student back table when you inserted the student details into the student table automatically. */
 
 -- Create the Student_details table
CREATE TABLE Student_details (
    Student_id INT PRIMARY KEY,
    Student_name VARCHAR(30),
    Mail_id VARCHAR(30),
    Mobile_no VARCHAR(14)
);

CREATE TABLE Student_details_backup (
    Student_id INT PRIMARY KEY,
    Student_name VARCHAR(30),
    Mail_id VARCHAR(30),
    Mobile_no VARCHAR(14),
    foreign key (Student_id)  references Student_details(Student_Id)
);


DELIMITER //
CREATE TRIGGER BackupStudentDetails
AFTER INSERT ON Student_details
FOR EACH ROW
BEGIN
    INSERT INTO Student_details_backup (Student_id, Student_name, Mail_id, Mobile_no)
    VALUES (NEW.Student_id, NEW.Student_name, NEW.Mail_id, NEW.Mobile_no);
END;
//
DELIMITER ;

# insert into parent table
insert into student_details values(101,"abhishek","abc@xyz.com",1112223334);
# check parent table
select * from student_details;
# check child table - it automatically updates child table
 # since trigger backupstudentdetails is executed as soon as values are inserted in parent table
select * from student_details_backup;



/* Extra Question - arrange no of matches played at stadium in 2018 and 2017 in descending order*/

select distinct ims.stadium_id,stadium_name, tournmt_id,count(ims.stadium_id) 
from ipl_match_schedule as ims join ipl_stadium as ips
on ims.stadium_id=ips.stadium_id
group by stadium_id,tournmt_id order by count(ims.stadium_id) desc;
 

/* Extra Question - display team names which qualified for playoffs. assume top 4 total_points for 2017 and 2018 */

select t.team_id, team_name,tournmt_id,total_points,playoff_rank from
(select its.team_id, tournmt_id,total_points, rank()over(partition by tournmt_id order by total_points desc) as playoff_rank
 from ipl_team_standings as its) as t
join ipl_team as it on t.team_id=it.team_id
where playoff_rank <5;


/* Extra Question - display best bidders on a per bid basis */
select * from ipl_bidder_points;
select ibp.bidder_id, bidder_name, total_points, no_of_bids, total_points/no_of_bids as points_per_bid
from ipl_bidder_points as ibp join ipl_bidder_details as ibd on ibp.bidder_id=ibd.bidder_id
order by points_per_bid desc;

/* Extra Question - display ipl team squad strength and strength of player role per team_id in descending order */
select * from ipl_team_players;
select distinct itp.team_id,team_name,player_role, count(player_id) over(partition by team_id,player_role)as count_player_role,
count(player_id) over(partition by team_id) as squad_strength 
from ipl_team_players as itp join ipl_team as it 
on itp.team_id=it.team_id
order by squad_strength desc;
 